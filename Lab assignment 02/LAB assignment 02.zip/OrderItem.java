public class OrderItem{
	private FoodItem;
	private int quantity;

		public OrderItem(FoodItem, int quantity){
		FoodItem = new FoodItem();
		this.quantity = quantity;}

	  public Order(OrderItem[] OrderItem) {
        this.Order= Order;
        this.OrderItem = new OrderItem();
    }
	public addItem(FoodItem,int OrderItem){
		this.FoodItem = FoodItem;
		this.OrderItem = OrderItem;
	}
	public void findItem(int FoodItem){
	return findItem;}
	public double calculateTotal(double total){
		this.total= +total;
	return total;
	}	
	public void DisplayOrder(){
		default = 5;
		System.out.println("The Order is: " : +OrderItem);



}