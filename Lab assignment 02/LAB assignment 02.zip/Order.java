public class Order{

	private int OrderNo;
	private int ItemCount;
	private OrderItem[] OrderItem;
		
		public Order(int Order, Customer){
			this.Order=Order;
}
		public Order(int Order , Customer, int ItemCount){
			this.Order = Order;
			this.ItemCount=ItemCount;
}
		
	  public Order(OrderItem[] OrderItem) {
        this.Order= Order;
        this.OrderItem = new OrderItem();
    }
	public addItem(FoodItem,int OrderItem){
		this.FoodItem = FoodItem;
		this.OrderItem = OrderItem;
	}
	public void findItem(int FoodItem){
	return findItem;}
	public double calculateTotal(double total){
		this.total= +total;
	return total;
	}	
	public void DisplayOrder(){
		default = 5;
		System.out.println("The Order is: " : +OrderItem);
}



}