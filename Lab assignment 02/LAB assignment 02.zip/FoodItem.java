public class FoodItem{

	private int ItemCode;
	private String Name;
	private double Price;
	private FoodCategory;

		public FoodItem(int ItemCode,String Name,double Price){
		this.ItemCode=ItemCode;
		this.Name=Name;
		this.Price=Price;
	 }
		public FoodItem(int ItemCode,String Name,double Price, FoodCategory){
			this.ItemCode=ItemCode;
			this.Name=Name;
			this.Price=Price;
			
		}	


	public void DisplayItem(){
		System.out.println("Display" +DisplayItem);}



}